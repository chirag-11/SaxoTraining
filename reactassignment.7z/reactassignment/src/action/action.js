import * as types from "../actionTypes/actionTypes.js";

export function incrementFunction()
{
    return {
        type:types.INCREMENT_COUNTER
    }
}
export function decrementFunction()
{
    return {
        type:types.DECREMENT_COUNTER
    }
}
export function resetFunction()
{
    return {
        type:types.RESET_COUNTER
    }
}