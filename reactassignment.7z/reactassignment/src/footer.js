import React from "react";

class Footer extends React.Component {
   render() {
      return (
         <div className="row"  style={{backgroundColor: "#808080", innerHeight:"302px",height:"400px",textAlign:"center" }}>
          <h1>Footer</h1>
          <p>@Copyright 2017 chirag</p>
         </div>
      );
   }
}

export default Footer