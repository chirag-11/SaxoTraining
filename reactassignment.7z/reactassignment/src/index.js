import React from "react"
import ReactDOM from "react-dom"
import Header from  "./header.js"
import Content from "./content.js"
import {combineReducers,createStore,applyMiddleware} from "redux";
import {logger,crashReporter} from "./middleware/middleware"
import Footer from "./footer.js"
import {Provider} from 'react-redux';

import {default as myreducers} from './reducer/reducer.js';
import {default as Increment} from './increment.js'
import {BrowserRouter as Router,Route,Link} from 'react-router-dom'


const reducers=combineReducers({
    state:myreducers
})

const store=createStore(reducers);
ReactDOM.render(

   
<Router>

        <div> 
           <Provider store={store}>
            <Increment />
        </Provider>
        </div>
        </Router>
        ,document.getElementById('container')
);
