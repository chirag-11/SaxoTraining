import React from "react";
import PropTypes from "prop-types";
import {connect } from "react-redux";
import * as stateActions from './action/action.js'



const mapStateToProps = state=>{
    console.log("mapStateToProps");
    var data ={
        counter:state.state.counter
    };

    return data;
} 

const mapDispatchToProps=dispatch=>({
    increment:()=>dispatch(stateActions.incrementFunction()),
     decrement:()=>dispatch(stateActions.decrementFunction())
})

class Increment extends React.Component
{
    static propTypes={
        dispatch:PropTypes.func.isRequired
    }
    render(){
        return(
         <div className ="inc">Total Value:
         <div id='counter'>{this.props.counter}</div> 
         <br></br>
         <br></br> 
         <button type="button" onClick={this.props.increment}>Increment</button>
         <button type="button" onClick={this.props.decrement}>Decrement</button>
      </div>  );
        
    }
}
Increment.defaultProps={
    counter:0
  
}
export default connect(mapStateToProps, mapDispatchToProps)(Increment)