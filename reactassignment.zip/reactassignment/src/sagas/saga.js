import React from "react";
import {delay} from "redux-saga";
import {call,put,takeEvery,all,race} from "redux-saga/effects";
import * as actionTypes from "../actionTypes/actionTypes.js";

export function* helloSaga(){
    console.log("hello to all from saaga");
}

export function* incrementAsync(){
    yield call(delay, 2000)
    yield put({type:actionTypes.INCREMENT_COUNTER})
}

export 
function* fetchPostsWithTimeout() {
  const {posts, timeout} = yield race({
    posts: call(delay, 5000),
    timeout: call(delay, 1000)
  })

  if (posts)
  {
console.log("posts");
    yield put({type:actionTypes.INCREMENT_COUNTER})
  }
  else
  { console.log("timeout")
       yield put({type: actionTypes.INCREMENT_COUNTER})
}
}

export function* watchIncrementAsync(){
    yield takeEvery(actionTypes.INCREMENT_COUNTER_ASYNC,fetchPostsWithTimeout)
}
export default function* rootSaga() {
  yield all([  helloSaga(),
    watchIncrementAsync()
  ])
}






