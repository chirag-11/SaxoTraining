import React from "react";
import Image from "./logo.jpg"
import {BrowserRouter as Router,Route,Link} from 'react-router-dom'
class Header extends React.Component {
   render() {
      return (
         <div className="row">
            <Logo/>
            <Menu />
         </div>
      );
   }
}


class Logo extends React.Component {
   render() {
      return (
         <div className="col-sm-1">
             <img src={Image} className="img-rounded"  width="150" height="100"></img>
         </div>
      );
   }
}

class Menu extends React.Component {
   render() {
      return (
         <div className="col-sm-11" style={{backgroundColor: "lightgrey", outerHeight:"100px;",height:"100px",fontSize:"25px"}}>
             <ul className="nav nav-pills nav-justified">
                <li><Link to ="/">Home</Link></li>
                <li><Link to ="/About">About</Link> </li>
                <li><Link to="/Contact">Contact</Link></li>
            
                </ul>
         </div>
      );
   }
}






export default Header