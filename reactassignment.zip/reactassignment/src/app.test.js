import React from 'react';
import {Test,watchAndLog} from './testing/unit.js';

it('sum should return sum',()=>
{
    var app =new Test();
    var sum=app.sum(1,2);
    expect(sum).toBe(3);
    
});


