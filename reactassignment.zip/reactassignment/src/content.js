import React from "react";
import {BrowserRouter as Router,Route,Link} from 'react-router-dom'
import {default as Increment} from './increment.js' 
class Content extends React.Component {
   render() {
      return (
         <div className="row" >
           
            <Body/>
         </div>
      );
   }
}


class Body extends React.Component {
   render() {
      return (
         <div className="Row" style={{backgroundColor: "#339966", innerHeight:"700px",height:"700px",textAlign:"center"}}>
            <Route exact path="/home" component={Home}/>
              <Route exact path="/About" component={About}/>
              <Route exact path="/Contact" component={Contact}/>
                       
         </div>
      );
   }
}
class Home extends React.Component{
    
   render() {
      return (
         <div  style={{backgroundColor: "lightblue", innerHeight:"700px",height:"700px",borderColor: 'black',fontSize:"20px",textAlign:"center"}}>
            <h1>Internal links</h1>
                <Link  to="/home/incrementer">Click to Open Incrementer</Link>
       
         <Route   path="/home/incrementer"   component={Increment}></Route> 
                
         </div>
      );
   }
}

class About extends React.Component{
    
   render() {
      return (
         <div style={{backgroundColor: "lightblue", innerHeight:"700px",height:"700px",borderColor: 'black',}}>
            <h1>About Saxo Bank Payments</h1>
             <h4>Saxo Payments is creating a marketplace where every member benefits from being p  <br></br>
              art of the community. The Saxo Payments Banking Circle offers its Members the  <br></br>
              capability to make and receive cross-border transfers in seconds rather than days,  <br></br>
               at very low cost in multiple currencies and in a secure and compliant cloud-based environment.  <br></br>
            Membership is open to card acquirers, PSPs, APMs, FX Payment Providers and Merchant Membership   <br></br>
            is open to merchants who join via their payment solution providers.</h4>
              
         </div>
      );
   }
}

class Contact extends React.Component{
    
   render() {
      return (
         <div  style={{backgroundColor: "lightblue", innerHeight:"700px",height:"700px",borderColor: 'black',}}>
        <CustomText></CustomText>
         </div>
      );
   }
}
class CustomText extends React.Component{
   constructor(props){
        super(props);
        this.state = {
            mytext:this.props.mytext,
            myemail:this.props.myemail
        }
     
      
        this.handleChange=this.handleChange.bind(this);
        this.handleChange1=this.handleChange1.bind(this);
    }
    
    handleChange(evt){
        this.setState({
        mytext:evt.target.value,
    })

    }
      handleChange1(evt){
        this.setState({
        myemail:evt.target.value,
    })
    
        
    }
ClickEvent(evt){
    alert("the form is sumbitted");
}
    render(){
        return(
            <div>NAME:
         <input type="text" onChange={this.handleChange} value={this.state.mytext} required></input>
         <br></br>
        <br></br><br></br>    
      EMAIL:   <input type="text" onChange={this.handleChange1} value={this.state.myemail} required></input>
        <br></br>
        <br></br>
        <button type="button" onClick={this.ClickEvent}>Submit</button>
      </div>  );
        
    }
}
CustomText.defaultProps={
    mytext:"Name",
    myemail:"email id "
}
/*
class Sum extends React.Component{
    
   render() {
      return (
         <div  style={{backgroundColor: "lightblue", innerHeight:"700px",height:"700px",borderColor: 'black',}}>
        <CustomCalc></CustomCalc>
         </div>
      );
   }
}


class CustomCalc extends React.Component{
   constructor(props){
        super(props);
        this.state = {
            mytext:this.props.mytext
          
        }
     this.DECEvent=this.DECEvent.bind(this);
       this.ClickEvent=this.ClickEvent.bind(this);
    
    }
  
ClickEvent(evt){
   
    this.setState({ 
mytext: this.state.mytext+ 1 
    }); 

}
DECEvent(evt){
    this.setState({
        mytext:this.state.mytext- 1
    })
}
    render(){
        return(
         <div>Total Value:
         <input type="number" value={this.state.mytext}></input>
         <br></br>
         <br></br> 
         <button type="button" onClick={this.ClickEvent}>Increment</button>
         <button type="button" onClick={this.DECEvent}>Decrement</button>
      </div>  );
        
    }
}
CustomCalc.defaultProps={
    mytext:1
  
}*/

export default Content