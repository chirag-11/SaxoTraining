import React from "react"
import ReactDOM from "react-dom"
//import Header from  "./header.js"
//import Content from "./content.js"
import {default as Increment} from "./container/AppRedux";
//import Footer from "./footer.js"
import {Provider} from 'react-redux';
import {combineReducers,createStore,applyMiddleware} from "redux";
import {default as myreducers} from './reducer/reducer.js';
//import {BrowserRouter as Router,Route,Link} from 'react-router-dom';
import {logger,crashReporter} from "./middleware/middleware"
import rootSaga from './sagas/saga.js';
import createSagaMiddleware from "redux-saga";

const sagaMiddleware=createSagaMiddleware();
const reducers=combineReducers({
    state:myreducers
})


const store=createStore(reducers,
applyMiddleware(sagaMiddleware)
);
sagaMiddleware.run(rootSaga);
ReactDOM.render(

   


        <div> 
           <Provider store={store}>
            <Increment />
        </Provider>
        </div>
        
        ,document.getElementById('container')
);
