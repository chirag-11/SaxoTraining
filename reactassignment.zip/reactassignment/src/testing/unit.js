import React from'react'
import ReactDOM from 'react-dom'

export class Test extends React.Component{
    sum(a,b)
    {
        return a+b;
    }
    render(){
        return "";
    }
}


export function* watchAndLog() {
  yield takeEvery('*', function* logger(action) {
    const state = yield select()

    console.log('action', action)
    console.log('state after', state)
  })
}